Disposable verification source copy. All application tests run only in fleet-02 Docker. No live deployment or real mail.
