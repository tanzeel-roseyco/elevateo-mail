Frozen BE02 + FE02 acceptance snapshot. Test and deployment status NOT_RUN. Source manifest is held by coordinator.
