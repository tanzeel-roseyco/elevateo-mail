import { expect } from '@playwright/test';
import type { Page, Response } from '@playwright/test';
import { join } from 'node:path';
import { writeFile } from 'node:fs/promises';
import { loadAcceptanceConfig, loadSeedContract } from '../shared/config.js';
import { loadCredentials } from './boundaries.js';

export const seed = (() => {
  try { return loadSeedContract(); }
  catch { throw new Error('Acceptance runtime seed unavailable or invalid'); }
})();
let screenshotBytes = 0;
export type Actor = keyof typeof seed.actors;
// AIDEV-NOTE: Observe only endpoint/status; never attach login/session headers or bodies.
export function responseAt(page: Page, path: string, method = 'GET'): Promise<Response> {
  return page.waitForResponse(response => {
    const url = new URL(response.url());
    return url.origin === 'http://app.test' && url.pathname === path && response.request().method() === method;
  });
}
export async function signIn(page: Page, actor: Actor = 'manager_primary'): Promise<void> {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Sign in', exact: true })).toBeVisible();
  await page.getByLabel('Email address', { exact: true }).fill(seed.actors[actor].email);
  await page.getByLabel('Password', { exact: true }).fill(loadCredentials().passwords[actor]);
  const [result] = await Promise.all([responseAt(page, '/v1/auth/login', 'POST'),
    page.getByRole('button', { name: 'Sign in', exact: true }).click()]);
  // AIDEV-NOTE: Auth-banned users fail before session creation; removed mailbox access still permits org login.
  expect(result.status()).toBe(actor === 'disabled' ? 401 : actor === 'no_membership' ? 404 : 200);
  if (actor === 'disabled') {
    await expect(page.getByRole('heading', { name: 'Sign in', exact: true })).toBeVisible();
    await expect(page.getByRole('alert')).toHaveText('Sign-in was not accepted. Check the email address and password, or recover access.');
    await expect(page.getByRole('button', { name: 'Account and sign-out' })).toHaveCount(0);
  } else if (actor === 'no_membership') {
    await expect(page.getByRole('heading', { name: 'No organization is available' })).toBeVisible();
  } else {
    await expect(page.getByRole('button', { name: 'Account and sign-out' })).toBeVisible();
  }
}
export async function mailbox(page: Page): Promise<void> {
  await page.goto(`/#/mailboxes/${seed.mailboxes.primary}`);
  await expect(page.getByRole('region', { name: 'Conversations', exact: true })).toBeVisible();
  await expect(page.locator(`a[data-thread][href="#/mailboxes/${seed.mailboxes.primary}/threads/${seed.data.thread_primary}"]`)).toBeVisible();
}
export async function openThread(page: Page): Promise<void> {
  await page.locator(`a[data-thread][href="#/mailboxes/${seed.mailboxes.primary}/threads/${seed.data.thread_primary}"]`).click();
  await expect(page.getByRole('article', { name: 'Conversation', exact: true })).toBeVisible();
  await expect(page.locator('pre').filter({ hasText: seed.data.marker }).first()).toBeVisible();
}
export async function screenshot(page: Page, id: string): Promise<string> {
  // AIDEV-NOTE: Callers prove content readiness first; authentication forms are never captured.
  const file = `native-private/${id}.png`;
  const config = loadAcceptanceConfig();
  const bytes = await page.screenshot({ fullPage: false });
  screenshotBytes += bytes.length;
  if (screenshotBytes > config.limits.artifactBytes) throw new Error('Screenshot budget exceeded');
  await writeFile(join(config.outputDir, file), bytes, { flag: 'wx', mode: 0o600 });
  return file;
}
