import { strict as assert } from 'node:assert';
import { mkdtemp, mkdir, readFile, rm, stat, symlink, writeFile, access } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { test } from 'node:test';
import { persistScreenshot } from './screenshots.js';

// AIDEV-NOTE: Fresh calls have no shared memory; preexisting files model a replaced worker's durable artifacts.
const first = 'SCN-READ-002-F1-unavailable';
const second = 'SCN-GUI-006-P-1280';
async function fixture(run: (directory: string, privateDir: string) => Promise<void>): Promise<void> {
  const directory = await mkdtemp(join(tmpdir(), 'acceptance-screenshots-'));
  const privateDir = join(directory, 'native-private');
  await mkdir(privateDir, { mode: 0o700 });
  try { await run(directory, privateDir); }
  finally { await rm(directory, { recursive: true, force: true }); }
}
test('replacement helper counts previous screenshot and enforces aggregate before persistence', async () => {
  await fixture(async (directory, privateDir) => {
    await persistScreenshot(directory, first, Buffer.alloc(6), 10);
    // A replacement process needs only these files, not the original helper or a module counter.
    const moduleURL = new URL('./screenshots.js?replacement', import.meta.url).href;
    const replacement = (await import(moduleURL)).persistScreenshot as typeof persistScreenshot;
    await assert.rejects(replacement(directory, second, Buffer.alloc(5), 10), /Screenshot budget exceeded/);
    await assert.rejects(access(join(privateDir, `${second}.png`)));
    await replacement(directory, second, Buffer.alloc(4), 10);
    assert.equal((await stat(join(privateDir, `${second}.png`))).mode & 0o777, 0o600);
    assert.equal((await stat(join(privateDir, `${first}.png`))).size, 6);
    await assert.rejects(access(join(privateDir, '.screenshots.lock')));
  });
});
test('exclusive artifact and lock creation prevent overwrite and concurrent writers', async () => {
  await fixture(async (directory, privateDir) => {
    await persistScreenshot(directory, first, Buffer.from('old'), 100);
    await assert.rejects(persistScreenshot(directory, first, Buffer.from('new'), 100));
    assert.equal(await readFile(join(privateDir, `${first}.png`), 'utf8'), 'old');
    await writeFile(join(privateDir, '.screenshots.lock'), '');
    await assert.rejects(persistScreenshot(directory, second, Buffer.alloc(1), 100));
    await assert.rejects(access(join(privateDir, `${second}.png`)));
  });
});
test('rejects path escape, linked artifact and linked directory without traversal', async () => {
  await fixture(async (directory, privateDir) => {
    await assert.rejects(persistScreenshot(directory, '../escape', Buffer.alloc(1), 100));
    await symlink('/missing-target', join(privateDir, `${first}.png`));
    await assert.rejects(persistScreenshot(directory, second, Buffer.alloc(1), 100), /Invalid screenshot artifact/);
    await assert.rejects(access(join(privateDir, `${second}.png`)));
    await rm(privateDir, { recursive: true });
    await symlink(directory, privateDir, 'dir');
    await assert.rejects(persistScreenshot(directory, second, Buffer.alloc(1), 100), /Invalid screenshot directory/);
  });
});
