#!/usr/bin/env bash
# AIDEV-NOTE: Separate Bash children keep mock OS/query boundaries out of the three actual database schedules.
set -euo pipefail
umask 077
[[ $# = 0 && -f /.dockerenv && ${BE02_GUARDS_DISPOSABLE:-} = 1 ]] || exit 1
test_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
scratch=$(mktemp -d /tmp/be02-concurrency-fixtures.XXXXXXXX)
cleanup() {
  local status=$? file
  trap - EXIT INT TERM
  for file in assertion fixture.log output events infra killed step; do
    rm -f -- "$scratch/$file" || status=1
  done
  rmdir -- "$scratch" || status=1
  exit "$status"
}
trap cleanup EXIT
trap 'exit 1' INT TERM
bash "$test_dir/auth-rls-concurrency-harness-regression-errors.sh" "$scratch" "$test_dir"
bash "$test_dir/auth-rls-concurrency-harness-regression-cleanup.sh" "$scratch" "$test_dir"
printf '%s\n' 'PASSED concurrency harness regressions: 18 diagnostic fixtures; 16 cleanup fixtures'
