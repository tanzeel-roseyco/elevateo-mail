import sys,json,os,time
from pathlib import Path
sys.path.insert(0,'/source/ops/selfhosted-mail')
from runtime_fixture import ROOT,configure,start,stop,command
from runtime_protocol import credentials
from runtime_dns import FixtureDNS
import runtime_fixture, runtime_protocol
runtime_fixture.ROOT=Path('/private/runtime');runtime_protocol.ROOT=runtime_fixture.ROOT;ROOT=runtime_fixture.ROOT
os.chown('/private',0,0); os.chmod('/private',0o755)
ca=configure(); dns=FixtureDNS(); dns.start(); process=None
try:
 process=start(ROOT)
 entries=[]; identities=[]
 for i in [0,1]:
  username,password=credentials(i); identities.append(username)
  command(ROOT,'setaccountpassword',username,data=(password+'\n').encode())
  for protocol in ['smtp','imap']:
   entries.append(dict(account_id=('11111111-1111-4111-8111-111111111111' if i==0 else '22222222-2222-4222-8222-222222222222'),organization_id='11111111-1111-4111-8111-111111111111',mailbox_id='11111111-1111-4111-8111-111111111111',credential_ref='secret:protocol-'+str(i),credential_version=1,protocol=protocol,username=username,password=password))
 for filename,value in [('bundle.json',dict(format_version=1,entries=entries)),('identities.json',identities)]:
  path=ROOT/filename;path.write_text(json.dumps(value));path.chmod(0o600);os.chown(path,10001,10001)
 # Root is traversable only inside this private disposable bind; credentials remain owner-only.
 ROOT.chmod(0o755);ca.chmod(0o644)
 (ROOT/'ready').touch()
 deadline=time.monotonic()+180
 while not (ROOT/'done').exists() and time.monotonic()<deadline:time.sleep(.2)
finally:
 if process:stop(process)
 dns.close()
