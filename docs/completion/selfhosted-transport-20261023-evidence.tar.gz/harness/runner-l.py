from pathlib import Path
import sys,os,fcntl,secrets,base64,re,time,json,traceback,signal
root=Path('/tmp/transport20261023-work/source')
sys.path.insert(0,str(root/'ops/tests/be02'))
from docker_task import Task
from run import bootstrap_database_roles,finalize,source_hashes
os.umask(0o077)
lease=open('/home/tanzeel/elevateo-mail-wave-20261014/control/soren-docker.lock','a')
signal.alarm(55)
fcntl.flock(lease,fcntl.LOCK_EX)
signal.alarm(0)
project='transport20261023-l'
evidence=root/'ops/local'/project;evidence.mkdir(parents=True,exist_ok=False)
values={k:secrets.token_hex(32) for k in ('POSTGRES_PASSWORD','MIGRATOR_DB_PASSWORD','API_DB_PASSWORD','WORKER_DB_PASSWORD','ATTACHMENT_GATEWAY_DB_PASSWORD','SECRET_KEY_BASE','BE02_FIXTURE_SIGNING_SECRET')}
values['ELEVATEO_SESSION_KEY_BASE64']=base64.b64encode(secrets.token_bytes(32)).decode()
task=Task(root,evidence,project,'default',values)
env={**values,'BE02_SOURCE':str(root),'BE02_PROJECT':project,'BE02_SERVER_IMAGE':task.image}
task.env_file.write_text(''.join(f'{k}={v}\n' for k,v in env.items()));task.env_file.chmod(0o600)
original=source_hashes(root);task.write('source.sha256.json',original)
status,failure,clean,armed='FAILED','',False,False
print('START '+project,flush=True)
try:
 endpoint=task.docker('endpoint',['context','inspect','default','--format','{{.Endpoints.docker.Host}}']).strip()
 if endpoint!='unix:///var/run/docker.sock': raise RuntimeError('nonlocal Docker endpoint')
 for kind in ('container','volume','network'):
  names=task.docker('admit-'+kind,[kind,'ls','-q','--filter','label=elevateo.be02.project='+project]).strip()
  if names: raise RuntimeError('namespace exists')
 task.docker('space-before',['system','df']);task.write('host-space-before.json',{'free_bytes':os.statvfs(evidence).f_bavail*os.statvfs(evidence).f_frsize})
 pins=set(re.findall(r'image: (\S+@sha256:[a-f0-9]{64})',(root/'ops/compose.be02-test.yaml').read_text()))
 for pin in pins: task.inspect('image',[pin])
 armed=True
 task.compose('validate',['config','--quiet'])
 task.compose('database-start',['up','-d','--wait','--wait-timeout','120','db','mailpit'],140)
 bootstrap_database_roles(task)
 task.compose('auth-start',['up','-d','--wait','--wait-timeout','120','auth'],140)
 task.compose('auth-grants',['run','--rm','--no-deps','bootstrap','-f','/ops/bootstrap-auth-grants.sql'],45)
 task.docker('pull-pinned-ruby',['pull','ruby:3.4.11-slim-bookworm@sha256:22165c5f904d76a8a02fbdd419d0269481369523fd66978232d16c88099730e2'],180)
 for p in (root/'apps/server/bin').iterdir(): p.chmod(0o755)
 print('BUILD',flush=True);task.build()
 task.compose('migrate',['run','--rm','--no-deps','migrate'],120)
 print('FINAL SOURCE CHECKS',flush=True)
 task.compose('enrollment-down',['run','--rm','--no-deps','migrate','bundle','exec','rails','db:migrate:down','VERSION=20261023000042'],60)
 task.compose('enrollment-up',['run','--rm','--no-deps','migrate','bundle','exec','rails','db:migrate:up','VERSION=20261023000042'],60)
 suite_failure=''
 try:task.compose('full-backend',['run','--rm','--no-deps','test'],1100)
 except RuntimeError as error:suite_failure=str(error)
 print('REAL MOX ADAPTER',flush=True)
 moxdir=Path('/tmp/transport20261023-work/protocol-l');moxdir.mkdir(mode=0o755)
 # generate() requires a nonexistent output target.
 runtime=moxdir/'runtime'
 resolver=moxdir/'resolv.conf';resolver.write_text('nameserver 127.0.0.1\n');resolver.chmod(0o644)
 helper=Path('/tmp/transport20261023-work/protocol.py');helper.chmod(0o644)
 moxname=project+'-mox'
 task.docker('mox-start',['run','-d','--name',moxname,'--network','none','--read-only','--memory','2g','--cpus','2','--pids-limit','128','--label','com.docker.compose.project='+project,'--tmpfs','/tmp:rw,nosuid,size=512m','--mount','type=bind,src='+str(moxdir)+',dst=/private','--mount','type=bind,src='+str(root)+',dst=/source,readonly','--mount','type=bind,src=/home/tanzeel/elevateo-mail-completion-20261015/control/mail1017/release/mox,dst=/release/mox,readonly','--mount','type=bind,src='+str(helper)+',dst=/protocol.py,readonly','--mount','type=bind,src='+str(resolver)+',dst=/etc/resolv.conf,readonly','--add-host','mail.dispatch.company.com:127.0.0.1','--add-host','mail.second.company.com:127.0.0.1','mcr.microsoft.com/playwright@sha256:35246d87a7c88ea9b771c65d33171b2611b02a8253b4b12ce6f94376c55f99f2','python3','/protocol.py'],30)
 try:
  until=time.monotonic()+65
  while not (runtime/'ready').exists():
   if time.monotonic()>until:raise RuntimeError('Mox fixture readiness timeout')
   time.sleep(.3)
  task.docker('ruby-mox-protocol',['run','--rm','--network','container:'+moxname,'--read-only','--memory','768m','--cpus','2','--label','com.docker.compose.project='+project,'--mount','type=bind,src='+str(runtime)+',dst=/fixture,readonly','--env','SSL_CERT_FILE=/fixture/ca.pem','--env','BE02_MOX_PRODUCTION_PROTOCOL=1','--env','BE02_MOX_PROTOCOL_DIRECTORY=/fixture',task.image,'bundle','exec','ruby','test/send_worker/production_mox_protocol_test.rb'],100)
 finally:
  if runtime.exists():(runtime/'done').touch()
  task.docker('mox-stop',['stop','--time','25',moxname],30,required=False)
  task.docker('mox-remove',['rm',moxname],20,required=False)
  # Delete only the exact private synthetic fixture, after its owned container stopped.
  import shutil
  if moxdir.resolve()==Path('/tmp/transport20261023-work/protocol-l'):shutil.rmtree(moxdir)
 if suite_failure:raise RuntimeError(suite_failure)

 status='PASSED'
except Exception as error:
 failure=task.redact(type(error).__name__+': '+str(error));print(failure,flush=True)
finally:
 status,failure,clean=finalize(task,False,armed,original,status,failure)
 task.docker('space-after',['system','df']);task.write('host-space-after.json',{'free_bytes':os.statvfs(evidence).f_bavail*os.statvfs(evidence).f_frsize})
 print(json.dumps({'status':status,'failure':failure,'cleanup':clean,'evidence':str(evidence)}),flush=True)
 fcntl.flock(lease,fcntl.LOCK_UN)
